<?php	$fname = $_REQUEST['fname'];
	$lname = $_REQUEST['lname'];
	echo "Welcome $fname $lname";	?>