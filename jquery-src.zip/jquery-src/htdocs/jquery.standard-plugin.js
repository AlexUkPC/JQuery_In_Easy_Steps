( function ( $ ) {

  $.fn.spotlight = function() {

    var hue = "yellow" ;

    this.css( "background" , hue ) ; 

    return this ;

  } ;

} ( jQuery ) ) ;