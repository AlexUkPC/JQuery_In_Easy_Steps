$.fn.spotlight = function() {

  this.css( "background" , "silver" ) ; 

} ;