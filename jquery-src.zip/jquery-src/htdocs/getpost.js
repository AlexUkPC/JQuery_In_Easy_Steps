function report( a ) { 
  $( "#out" ).text( a.page +" at "+ a.date +" via "+ a.type ) ; 
}