$.fn.spotlight = function() {

  this.css( "background" , "silver" ) ; 

  return this ;

} ;